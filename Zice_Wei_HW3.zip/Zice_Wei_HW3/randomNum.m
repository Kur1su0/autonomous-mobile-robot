function [x] = randomNum(Min,Max)
%RANDOMPOS Summary of this function goes here
%   Detailed explanation goes here
x = Min + rand*(Max-Min);
end

